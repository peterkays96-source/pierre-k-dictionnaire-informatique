# PIERRE K – Dictionnaire informatique

Projet Android natif en Kotlin + Jetpack Compose.

## Fonctionnalités de cette version enrichie
- Dictionnaire français avec traduction anglaise.
- Filtres : Tous, Débutant, Intermédiaire, Avancé.
- Recherche par terme français, anglais, définition ou exemple.
- 75 entrées environ, avec traductions, niveaux et exemples pratiques.
- Favoris sauvegardés sur le téléphone.
- Définitions et exemples disponibles hors connexion.

## Compilation en APK
1. Ouvrir ce dossier dans Android Studio sur un ordinateur.
2. Laisser Gradle synchroniser les dépendances (Internet requis pour la première compilation).
3. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Le fichier APK sera normalement créé dans `app/build/outputs/apk/debug/`.

## Important
Ce dossier contient le code source du projet, pas encore un APK compilé. Il faudra compiler et tester l'application sur Android avant de la distribuer.
