package com.pierrek.dictionnaire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Term(val fr: String, val en: String, val level: String, val definition: String, val example: String)

private val terms = listOf(
    Term("Algorithme", "Algorithm", "Débutant", "Suite d'étapes précises permettant de résoudre un problème ou d'effectuer une tâche.", "Un algorithme peut expliquer comment trier une liste de nombres."),
    Term("Application", "Application / App", "Débutant", "Programme conçu pour réaliser une ou plusieurs tâches pour l'utilisateur.", "Une application de dictionnaire permet de rechercher des mots."),
    Term("Base de données", "Database", "Débutant", "Ensemble organisé d'informations que l'on peut consulter, ajouter ou modifier.", "Un carnet de contacts est une petite base de données."),
    Term("Bluetooth", "Bluetooth", "Débutant", "Technologie sans fil permettant à des appareils proches d'échanger des données.", "On peut connecter un téléphone à un casque Bluetooth."),
    Term("Cloud", "Cloud computing", "Intermédiaire", "Utilisation de serveurs distants accessibles par Internet pour stocker ou traiter des données.", "Google Drive permet de stocker des fichiers dans le cloud."),
    Term("Code source", "Source code", "Débutant", "Texte écrit dans un langage de programmation et utilisé pour construire un logiciel.", "Le code source décrit le fonctionnement d'une application."),
    Term("Compilateur", "Compiler", "Intermédiaire", "Outil qui transforme un programme en une forme exécutable par une machine ou une plateforme.", "Un compilateur peut transformer du Kotlin en code destiné à Android."),
    Term("Cryptage", "Encryption", "Intermédiaire", "Transformation de données afin de les rendre illisibles sans la clé appropriée.", "Le chiffrement protège certains échanges sur Internet."),
    Term("CPU / Processeur", "CPU / Processor", "Débutant", "Composant qui exécute les instructions et effectue les calculs d'un appareil.", "Le processeur est souvent appelé le cerveau de l'ordinateur."),
    Term("DNS", "Domain Name System", "Avancé", "Système qui traduit les noms de domaine en adresses IP.", "Le DNS aide le navigateur à trouver le serveur d'un site."),
    Term("Donnée", "Data", "Débutant", "Information pouvant être enregistrée, traitée ou transmise par un système.", "Une photo numérique est une donnée."),
    Term("Fichier", "File", "Débutant", "Ensemble d'informations enregistré sous un nom dans un appareil.", "Une image JPG est un fichier."),
    Term("Firewall / Pare-feu", "Firewall", "Intermédiaire", "Système qui filtre les connexions réseau selon des règles de sécurité.", "Un pare-feu peut bloquer une connexion non autorisée."),
    Term("HTML", "HyperText Markup Language", "Débutant", "Langage de balisage utilisé pour structurer le contenu des pages Web.", "HTML sert à organiser les titres, paragraphes et liens."),
    Term("HTTP", "HyperText Transfer Protocol", "Intermédiaire", "Protocole utilisé pour échanger des ressources entre un navigateur et un serveur Web.", "Une page Web est souvent chargée avec HTTP ou HTTPS."),
    Term("HTTPS", "HyperText Transfer Protocol Secure", "Intermédiaire", "Version sécurisée de HTTP qui protège les échanges grâce au chiffrement TLS.", "Le cadenas du navigateur indique généralement une connexion HTTPS."),
    Term("Adresse IP", "IP address", "Débutant", "Numéro qui identifie une interface sur un réseau utilisant le protocole IP.", "Un routeur attribue souvent une adresse IP aux téléphones connectés."),
    Term("Interface", "Interface", "Débutant", "Partie d'un logiciel avec laquelle l'utilisateur interagit.", "Les boutons et menus forment une interface."),
    Term("Java", "Java", "Intermédiaire", "Langage de programmation polyvalent utilisé notamment dans les applications et systèmes.", "Java est utilisé dans de nombreux projets Android."),
    Term("JavaScript", "JavaScript", "Intermédiaire", "Langage de programmation très utilisé pour rendre les pages Web interactives.", "JavaScript peut réagir lorsqu'on appuie sur un bouton."),
    Term("Kotlin", "Kotlin", "Intermédiaire", "Langage de programmation moderne utilisé notamment pour développer des applications Android.", "Cette application de démonstration est écrite en Kotlin."),
    Term("Logiciel", "Software", "Débutant", "Ensemble de programmes qui permettent à un appareil d'effectuer des tâches.", "Un navigateur est un logiciel."),
    Term("Mémoire RAM", "RAM", "Débutant", "Mémoire temporaire utilisée par les programmes pendant leur fonctionnement.", "Plusieurs applications ouvertes utilisent de la RAM."),
    Term("Navigateur", "Browser", "Débutant", "Logiciel qui permet de consulter des sites et des pages Web.", "Chrome est un navigateur."),
    Term("Octet", "Byte", "Débutant", "Unité de mesure de l'information numérique, généralement composée de huit bits.", "Un fichier peut peser plusieurs mégaoctets."),
    Term("Pare-feu", "Firewall", "Intermédiaire", "Voir « Firewall » : outil de filtrage du trafic réseau.", "Il peut limiter les connexions entrantes."),
    Term("Protocole", "Protocol", "Intermédiaire", "Ensemble de règles permettant à des appareils ou logiciels de communiquer.", "TCP et IP sont des protocoles réseau."),
    Term("Réseau", "Network", "Débutant", "Ensemble d'appareils reliés pour échanger des données ou partager des ressources.", "Un Wi-Fi domestique forme un réseau local."),
    Term("Routeur", "Router", "Débutant", "Appareil qui dirige les données entre différents réseaux.", "Un routeur relie souvent le réseau local à Internet."),
    Term("Serveur", "Server", "Intermédiaire", "Ordinateur ou programme qui fournit des services ou des ressources à d'autres appareils.", "Un serveur Web envoie les pages demandées."),
    Term("Système d'exploitation", "Operating system", "Débutant", "Logiciel principal qui gère le matériel et permet aux applications de fonctionner.", "Android et Windows sont des systèmes d'exploitation."),
    Term("TCP/IP", "Transmission Control Protocol / Internet Protocol", "Avancé", "Ensemble de protocoles fondamentaux utilisés pour faire communiquer les appareils sur Internet.", "TCP/IP permet l'acheminement des données entre réseaux."),
    Term("URL", "Uniform Resource Locator", "Débutant", "Adresse qui indique l'emplacement d'une ressource sur le Web.", "L'adresse d'un site est une URL."),
    Term("USB", "Universal Serial Bus", "Débutant", "Norme de connexion utilisée pour transférer des données et fournir de l'énergie.", "Un câble USB peut recharger un téléphone."),
    Term("VPN", "Virtual Private Network", "Intermédiaire", "Technologie qui crée un tunnel sécurisé entre un appareil et un réseau distant.", "Un VPN peut protéger le trafic sur un Wi-Fi public."),
    Term("Wi-Fi", "Wi-Fi", "Débutant", "Technologie de réseau local sans fil permettant de connecter des appareils.", "Un téléphone peut accéder à Internet par Wi-Fi.")
,
    Term("Antivirus", "Antivirus", "Débutant", "Logiciel qui détecte, bloque ou supprime certains programmes malveillants.", "Un antivirus peut analyser les fichiers téléchargés."),
    Term("Authentification", "Authentication", "Intermédiaire", "Vérification de l’identité d’un utilisateur avant de lui donner accès à un service.", "Un code envoyé par SMS peut servir à confirmer une connexion."),
    Term("Bande passante", "Bandwidth", "Intermédiaire", "Capacité d’une connexion réseau à transporter des données pendant une durée donnée.", "Une bande passante plus élevée peut faciliter le téléchargement de gros fichiers."),
    Term("Bit", "Bit", "Débutant", "Plus petite unité d’information numérique, qui vaut 0 ou 1.", "Un octet contient généralement huit bits."),
    Term("Cache", "Cache", "Intermédiaire", "Zone de stockage temporaire qui conserve des données pour accélérer leur accès ultérieur.", "Le navigateur garde parfois des images en cache pour charger les pages plus vite."),
    Term("Captcha", "CAPTCHA", "Débutant", "Test destiné à distinguer un humain d’un programme automatisé.", "Un site peut demander de cocher une case ou de reconnaître des images."),
    Term("Carte mère", "Motherboard", "Intermédiaire", "Circuit principal qui relie les composants essentiels d’un ordinateur.", "Le processeur et la mémoire vive sont connectés à la carte mère."),
    Term("Clavier", "Keyboard", "Débutant", "Périphérique permettant de saisir du texte et des commandes.", "On utilise le clavier pour écrire un message."),
    Term("Compte utilisateur", "User account", "Débutant", "Ensemble d’informations qui identifie une personne sur un appareil ou un service.", "Chaque membre d’une famille peut avoir son propre compte sur un ordinateur."),
    Term("Cookie", "Cookie", "Intermédiaire", "Petit fichier ou élément de données qu’un site conserve dans le navigateur.", "Un cookie peut mémoriser la langue choisie sur un site."),
    Term("Débogage", "Debugging", "Intermédiaire", "Recherche et correction des erreurs dans un programme.", "Le développeur débogue son application lorsqu’un bouton ne fonctionne pas."),
    Term("Débit", "Data rate / Throughput", "Débutant", "Quantité de données transférées pendant une période donnée.", "On peut mesurer le débit Internet en mégabits par seconde."),
    Term("Dossier", "Folder", "Débutant", "Emplacement utilisé pour regrouper et organiser des fichiers.", "On peut créer un dossier pour classer ses photos."),
    Term("E-mail / Courriel", "Email", "Débutant", "Message électronique envoyé ou reçu par Internet.", "On peut envoyer un document par e-mail."),
    Term("Extension de fichier", "File extension", "Intermédiaire", "Suffixe du nom d’un fichier qui indique souvent son format.", "Dans rapport.pdf, « .pdf » est l’extension."),
    Term("Galerie", "Gallery", "Débutant", "Application ou espace qui permet de consulter les photos et vidéos.", "La galerie affiche les photos enregistrées sur le téléphone."),
    Term("Gigaoctet", "Gigabyte (GB)", "Débutant", "Unité de capacité numérique correspondant à environ un milliard d’octets en usage courant.", "Une carte mémoire de 32 Go peut stocker de nombreux fichiers."),
    Term("Hébergement Web", "Web hosting", "Intermédiaire", "Service qui met les fichiers d’un site sur un serveur accessible par Internet.", "Un site doit être hébergé pour être consultable en ligne."),
    Term("Icône", "Icon", "Débutant", "Petit symbole graphique représentant une application, un fichier ou une action.", "On touche l’icône de l’appareil photo pour ouvrir la caméra."),
    Term("Installation", "Installation", "Débutant", "Opération qui prépare un logiciel ou une application à être utilisé sur un appareil.", "L’installation d’une application Android se fait généralement depuis un fichier APK ou une boutique."),
    Term("Java Virtual Machine (JVM)", "Java Virtual Machine", "Avancé", "Environnement qui exécute le bytecode Java sur une plateforme compatible.", "La JVM permet d’exécuter le même bytecode sur différents systèmes compatibles."),
    Term("Lien hypertexte", "Hyperlink", "Débutant", "Élément cliquable qui dirige vers une autre page, un fichier ou une ressource.", "Un lien bleu dans un texte peut ouvrir un site Web."),
    Term("Maliciel", "Malware", "Intermédiaire", "Logiciel conçu pour nuire à un appareil, voler des données ou perturber son fonctionnement.", "Une pièce jointe frauduleuse peut contenir un maliciel."),
    Term("Modem", "Modem", "Intermédiaire", "Équipement qui permet d’établir une connexion avec un réseau d’accès à Internet.", "Un modem 4G utilise le réseau mobile pour fournir Internet."),
    Term("Mot de passe", "Password", "Débutant", "Secret utilisé pour protéger l’accès à un compte ou à un appareil.", "Il faut choisir un mot de passe long et difficile à deviner."),
    Term("Notification", "Notification", "Débutant", "Message affiché par un appareil ou une application pour signaler une information.", "Une notification peut prévenir de l’arrivée d’un nouveau message."),
    Term("Navigateur privé", "Private browsing", "Intermédiaire", "Mode de navigation qui limite l’enregistrement local de certaines données de session.", "Le mode privé évite généralement de conserver l’historique de cette session sur l’appareil."),
    Term("Pare-feu réseau", "Network firewall", "Avancé", "Dispositif matériel ou logiciel qui contrôle le trafic entre des réseaux selon des règles.", "Une entreprise peut filtrer les connexions entre son réseau interne et Internet."),
    Term("Pixel", "Pixel", "Débutant", "Plus petit élément adressable d’une image numérique matricielle.", "Une photo de grande résolution contient beaucoup de pixels."),
    Term("Port USB", "USB port", "Débutant", "Connecteur physique permettant de brancher un appareil ou un accessoire USB.", "On branche une clé USB dans un port USB compatible."),
    Term("Sauvegarde", "Backup", "Débutant", "Copie de données conservée pour pouvoir les récupérer en cas de perte.", "Faire une sauvegarde protège les photos si le téléphone tombe en panne."),
    Term("Sécurité informatique", "Cybersecurity / IT security", "Intermédiaire", "Ensemble des pratiques visant à protéger les appareils, réseaux et données.", "Les mises à jour et les mots de passe solides améliorent la sécurité informatique."),
    Term("Téléchargement", "Download", "Débutant", "Transfert d’un fichier ou de données depuis un service distant vers son appareil.", "Télécharger une photo signifie la récupérer sur son téléphone."),
    Term("Téléversement", "Upload", "Intermédiaire", "Transfert d’un fichier depuis son appareil vers un serveur ou un service en ligne.", "Envoyer une photo dans le cloud est un téléversement."),
    Term("Utilisateur", "User", "Débutant", "Personne qui utilise un appareil, un logiciel ou un service numérique.", "L’utilisateur peut modifier les paramètres de son téléphone."),
    Term("Version", "Version", "Débutant", "État identifié d’un logiciel à une étape de son évolution.", "Une mise à jour peut faire passer une application à une nouvelle version."),
    Term("Web", "Web / World Wide Web", "Débutant", "Ensemble de pages et de ressources reliées entre elles et accessibles via Internet.", "On consulte le Web avec un navigateur."),
    Term("Webmaster", "Webmaster", "Intermédiaire", "Personne chargée de gérer, maintenir ou administrer un site Web.", "Le webmaster vérifie que les pages du site fonctionnent correctement."),
    Term("ZIP", "ZIP archive", "Intermédiaire", "Format de fichier permettant de regrouper et souvent de compresser plusieurs fichiers.", "On peut envoyer plusieurs documents réunis dans une archive ZIP.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("pierre_k", MODE_PRIVATE)
        setContent {
            var query by remember { mutableStateOf("") }
            var level by remember { mutableStateOf("Tous") }
            var favoritesOnly by remember { mutableStateOf(false) }
            var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
            var selected by remember { mutableStateOf<Term?>(null) }
            val navy = Color(0xFF142B45)
            val filtered = terms.filter {
                (level == "Tous" || it.level == level) &&
                (!favoritesOnly || favorites.contains(it.fr)) &&
                (query.isBlank() || it.fr.contains(query, true) || it.en.contains(query, true) || it.definition.contains(query, true) || it.example.contains(query, true))
            }.sortedBy { it.fr.lowercase() }

            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B87), secondary = Color(0xFF279B70))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F7FA)) {
                    if (selected == null) {
                        Column(Modifier.fillMaxSize().padding(16.dp)) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(22.dp),
                                colors = CardDefaults.cardColors(containerColor = navy)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                    Text("PIERRE K", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("DICTIONNAIRE INFORMATIQUE", color = Color(0xFF9FE3E8), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("Apprendre • Comprendre • Progresser", color = Color.White.copy(alpha = 0.88f), fontSize = 13.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = 0.14f)) {
                                        Text("${terms.size} termes disponibles  ·  Hors connexion", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                                    }
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            OutlinedTextField(
                                value = query, onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Rechercher un terme ou une traduction") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf("Tous", "Débutant", "Intermédiaire", "Avancé").forEach { item ->
                                    FilterChip(selected = level == item, onClick = { level = item }, label = { Text(item, fontSize = 12.sp) })
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = favoritesOnly, onCheckedChange = { favoritesOnly = it })
                                Text("Afficher uniquement mes favoris")
                            }
                            Text("${filtered.size} terme(s)", color = Color.Gray, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(filtered) { term ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth().clickable { selected = term },
                                        shape = RoundedCornerShape(18.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White)
                                    ) {
                                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(term.fr, color = navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                                Text(term.en, color = Color(0xFF176B87), fontSize = 13.sp)
                                                Text(term.level.uppercase(), color = Color(0xFF547080), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.7.sp)
                                            }
                                            Text(if (favorites.contains(term.fr)) "★" else "☆", fontSize = 24.sp, color = Color(0xFFE2A52B),
                                                modifier = Modifier.clickable {
                                                    favorites = if (favorites.contains(term.fr)) favorites - term.fr else favorites + term.fr
                                                    prefs.edit().putStringSet("favorites", favorites).apply()
                                                }.padding(6.dp))
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("PIERRE K • Version 1.1 • Fonctionne hors connexion", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                        }
                    } else {
                        val term = selected!!
                        Column(Modifier.fillMaxSize().padding(20.dp)) {
                            Text("‹ Retour au dictionnaire", color = Color(0xFF176B87), modifier = Modifier.clickable { selected = null }, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(28.dp))
                            Text(term.fr, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = navy)
                            Text(term.en, fontSize = 18.sp, color = Color(0xFF176B87))
                            Spacer(Modifier.height(10.dp))
                            AssistChip(onClick = {}, label = { Text(term.level) })
                            Spacer(Modifier.height(22.dp))
                            Text("DÉFINITION", color = Color.Gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(term.definition, fontSize = 17.sp, lineHeight = 25.sp)
                            Spacer(Modifier.height(22.dp))
                            Text("EXEMPLE", color = Color.Gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(term.example, fontSize = 16.sp, lineHeight = 24.sp)
                            Spacer(Modifier.height(24.dp))
                            Button(onClick = {
                                favorites = if (favorites.contains(term.fr)) favorites - term.fr else favorites + term.fr
                                prefs.edit().putStringSet("favorites", favorites).apply()
                            }) { Text(if (favorites.contains(term.fr)) "Retirer des favoris" else "Ajouter aux favoris") }
                        }
                    }
                }
            }
        }
    }
}
